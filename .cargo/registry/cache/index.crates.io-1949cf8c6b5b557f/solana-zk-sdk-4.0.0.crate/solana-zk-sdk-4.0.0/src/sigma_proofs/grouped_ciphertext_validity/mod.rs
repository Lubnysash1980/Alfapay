mod handles_2;
mod handles_3;

pub use {
    handles_2::GroupedCiphertext2HandlesValidityProof,
    handles_3::GroupedCiphertext3HandlesValidityProof,
};
