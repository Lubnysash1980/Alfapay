#![feature(test)]
extern crate test;

mod bls12_381;
