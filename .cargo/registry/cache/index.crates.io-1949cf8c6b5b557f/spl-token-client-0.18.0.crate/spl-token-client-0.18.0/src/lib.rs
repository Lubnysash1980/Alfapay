#![allow(clippy::arithmetic_side_effects)]
pub mod client;
pub mod output;
pub mod token;

pub use spl_token_2022;
