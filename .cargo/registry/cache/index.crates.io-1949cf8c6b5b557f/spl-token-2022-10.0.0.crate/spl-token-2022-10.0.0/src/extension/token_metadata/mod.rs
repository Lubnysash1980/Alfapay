/// Instruction processor for the `TokenMetadata` extension
pub mod processor;
