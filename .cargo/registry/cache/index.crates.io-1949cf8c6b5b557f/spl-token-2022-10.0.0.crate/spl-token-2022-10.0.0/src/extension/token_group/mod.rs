/// Instruction processor for the `TokenGroup` extension
pub mod processor;
