#[deprecated(since = "2.0.0", note = "Please use `compute_budget` instead")]
pub use crate::compute_budget::{compute_unit_price_arg, COMPUTE_UNIT_PRICE_ARG};
