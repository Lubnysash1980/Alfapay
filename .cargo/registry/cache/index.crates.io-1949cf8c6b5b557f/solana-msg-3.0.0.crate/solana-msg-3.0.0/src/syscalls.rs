/// Syscall definitions used by `solana_msg`.
pub use solana_define_syscall::definitions::{
    sol_log_, sol_log_64_, sol_log_compute_units_, sol_log_data,
};
