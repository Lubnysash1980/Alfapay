# Changelog

## [1.0.0] - 2025-07-12

Switch to `core::error`, remove std feature and set msrv to 1.81 [(#13)](https://github.com/kevinheavey/five8/pull/13)

## [0.1.2] - 2025-03-19

Add missing `#![no_std]` [(#10)](https://github.com/kevinheavey/five8/pull/10)

## [0.1.1] - 2024-10-13

- Add feature information to docs via `doc_auto_cfg` [(#7)](https://github.com/kevinheavey/five8/pull/7) 

## [0.1.0] - 2024-07-30

First release!
