# Record

On-chain program for writing arbitrary data to an account, authorized by an
owner of the account.

## Audit

The repository [README](https://github.com/solana-labs/solana-program-library#audits)
contains information about program audits.
