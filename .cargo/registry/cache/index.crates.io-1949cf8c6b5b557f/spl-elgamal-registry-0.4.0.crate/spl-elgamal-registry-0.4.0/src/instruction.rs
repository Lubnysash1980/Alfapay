#![deprecated(
    since = "0.4.0",
    note = "Use spl_elgamal_registry_interface::instruction"
)]
pub use spl_elgamal_registry_interface::instruction::*;
