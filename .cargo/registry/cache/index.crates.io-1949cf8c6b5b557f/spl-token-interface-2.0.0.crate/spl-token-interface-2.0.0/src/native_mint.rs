//! The Mint that represents the native token

/// There are `10^9` lamports in one SOL
pub const DECIMALS: u8 = 9;

// The Mint for native SOL Token accounts
solana_pubkey::declare_id!("So11111111111111111111111111111111111111112");
