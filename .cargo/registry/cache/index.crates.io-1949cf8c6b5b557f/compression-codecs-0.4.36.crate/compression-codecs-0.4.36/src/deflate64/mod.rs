mod decoder;

pub use self::decoder::Deflate64Decoder;
