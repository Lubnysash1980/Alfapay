mod decoder;
mod encoder;
pub mod params;

pub use self::{decoder::Lz4Decoder, encoder::Lz4Encoder};
